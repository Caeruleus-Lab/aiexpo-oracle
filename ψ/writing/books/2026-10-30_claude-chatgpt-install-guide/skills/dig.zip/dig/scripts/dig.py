#!/usr/bin/env python3
"""Session goldminer v3 — scan Claude Code .jsonl files for session timeline.

Fixes (ported from home-comming-oracle/dig-deep.py):
- --deep now scans subagent dirs: <project>/<uuid>/subagents/*.jsonl
- --subagents alias for explicit subagent inclusion
- Proper timezone detection (MAW_DISPLAY_TZ > TZ > system > UTC)
- Coverage metadata entry appended to output when --deep is used
- toolCalls, fileSizeKB, isSubagent fields added in --deep mode
"""
import json, os, glob, sys, subprocess, re
from datetime import datetime, timedelta
from pathlib import Path

project_dirs = [d for d in os.environ.get('PROJECT_DIRS', '').split(':') if d]

# Parse flags and positional args
_raw_args = sys.argv[1:]
deep = '--deep' in _raw_args
include_subagents = '--subagents' in _raw_args
skip_current = '--skip-current' in _raw_args
_positional = [a for a in _raw_args if not a.startswith('--')]
count = int(_positional[0]) if _positional else 10  # 0 = no limit

# The session running this script is always the newest file, because it is
# being written right now. /recap asks for "the last session" with `dig.py 1`,
# so without --skip-current it gets itself back: measured 2026-09-26 on a
# resumed session, "last session" was the current one, 4,709 min long.
# The host names its own session in the env (same keys and shape check as
# agents-relic's sessionIdFromEnv); with no id, the youngest file is treated
# as the current one (the same rule relic's `tail` uses).
current_sid = ''
for _k in ('CLAUDE_CODE_SESSION_ID', 'CODEX_THREAD_ID', 'CODEX_COMPANION_SESSION_ID'):
    _v = os.environ.get(_k, '').strip()
    if re.match(r'^[0-9a-fA-F][0-9a-fA-F-]{7,}$', _v):
        current_sid = _v
        break


# Turns in the user channel that the HOST wrote, not the human. Measured on the
# session that prompted this: the first "prompt" was a <local-command-caveat>,
# and skill bodies, task notifications and teammate messages were counted as
# human messages. Same shapes as agents-relic's isHarnessTurn (src/recap.ts).
HARNESS_PREFIXES = (
    '<local-command-caveat>', '<local-command-stdout>', 'Caveat: The messages below',
    '<command-name>', '<command-message>', '<command-args>',
    'Base directory for this skill:', '<system-reminder>',
    '<bash-stdout>', '<bash-stderr>', '<task-notification>',
    'Another Claude session sent a message:', '<teammate-message',
    'This session is being continued from a previous conversation',
    '[Request interrupted',
)


def is_harness_turn(obj, text):
    if obj.get('isMeta') or obj.get('isCompactSummary'):
        return True
    return text.startswith(HARNESS_PREFIXES)


def detect_tz():
    """Detect local timezone offset. Priority: MAW_DISPLAY_TZ > TZ > system > UTC."""
    for var in ('MAW_DISPLAY_TZ', 'TZ'):
        val = os.environ.get(var, '')
        if val:
            try:
                return timedelta(hours=int(val)), f"GMT+{val}"
            except ValueError:
                pass
    try:
        r = subprocess.run(['date', '+%z'], capture_output=True, text=True, timeout=3)
        offset_str = r.stdout.strip()
        if offset_str and len(offset_str) >= 5:
            sign = 1 if offset_str[0] == '+' else -1
            hours = int(offset_str[1:3])
            mins = int(offset_str[3:5])
            total = sign * (hours * 60 + mins)
            label = f"GMT{offset_str[0]}{hours:02d}:{mins:02d}"
            return timedelta(minutes=total), label
    except:
        pass
    return timedelta(hours=0), "UTC"


tz_offset, tz_name = detect_tz()


def build_repo_map():
    # `ghq list -p` maps encoded project-dir names → real repo names, but it can
    # take several seconds on machines with a large ghq root — and it runs on
    # every dig/recap/rrr invocation. DIG_SKIP_REPO_MAP=1 skips the subprocess
    # entirely: repo names then fall back to get_repo_name()'s own parsing. The
    # e2e test sets it so it stays hermetic (no ghq dependency) and fast.
    if os.environ.get('DIG_SKIP_REPO_MAP', '').lower() in ('1', 'true', 'yes', 'on'):
        return {}
    mapping = {}
    try:
        r = subprocess.run(['ghq', 'list', '-p'], capture_output=True, text=True, timeout=5)
        for path in r.stdout.strip().split('\n'):
            if path:
                mapping[path.replace('/', '-').replace('.', '-')] = path.split('/')[-1]
    except:
        pass
    return mapping


def get_repo_name(project_dir, repo_map):
    base = os.path.basename(project_dir.rstrip('/'))
    clean = re.sub(r'-(wt|agents)-.*$', '', base)   # strip -wt-1, -wt-herdr-…, -agents-1-gpu
    return repo_map.get(clean) or clean.split('-')[-1] or clean


repo_map = build_repo_map()

# ── Collect .jsonl files ──────────────────────────────────────────────────────
all_files = []   # list of (filepath, project_dir, is_subagent)
total_found = 0

skipped_unreadable = 0  # dangling symlinks / files pruned mid-scan
for d in project_dirs:
    # Top-level sessions (always included)
    for f in glob.glob(os.path.join(d, '*.jsonl')):
        all_files.append((f, d, False))
        total_found += 1

    # Deep scan: subagent sessions inside <uuid>/subagents/
    if deep or include_subagents:
        for uuid_dir in glob.glob(os.path.join(d, '*')):
            if not os.path.isdir(uuid_dir):
                continue
            sub_dir = os.path.join(uuid_dir, 'subagents')
            if os.path.isdir(sub_dir):
                # Direct subagents, PLUS the workflow tier one level deeper.
                # Until 2026-09-18 this globbed only sub_dir, so every agent
                # spawned inside a workflow run was invisible: measured on one
                # project dir, 13 transcripts found vs 118 actually present —
                # 105 workflow agents missing, i.e. the whole of any fan-out.
                candidates = list(glob.glob(os.path.join(sub_dir, '*.jsonl')))
                for wf_dir in glob.glob(os.path.join(sub_dir, 'workflows', 'wf_*')):
                    for wf_f in glob.glob(os.path.join(wf_dir, '*.jsonl')):
                        # journal.jsonl is run bookkeeping, not a transcript
                        if os.path.basename(wf_f) != 'journal.jsonl':
                            candidates.append(wf_f)
                for f in candidates:
                    # getsize() follows symlinks and raises on a dangling one.
                    # Archived roots are full of links into the LIVE root, and
                    # those break as soon as a session is pruned there — one
                    # dangling link used to abort the entire scan and emit zero
                    # sessions, which reads as "no history" (measured 2026-09-17:
                    # 38,764 files, 1 bad link, 0 output).
                    try:
                        if os.path.getsize(f) > 0:
                            all_files.append((f, d, True))
                            total_found += 1
                    except OSError:
                        skipped_unreadable += 1
                        continue

# Prune anything that cannot be stat'd BEFORE any getmtime/getsize below.
# Archived roots link into the live root; those links break when a session is
# pruned there. Doing this once here covers the dedup (getmtime), the sort
# (getmtime) and fileSizeKB — each of which used to abort the whole run on a
# single bad path, emitting zero sessions, which reads as "no history".
_kept = []
for _entry in all_files:
    if os.path.exists(_entry[0]):
        _kept.append(_entry)
    else:
        skipped_unreadable += 1
all_files = _kept

# Deduplicate
if deep or include_subagents:
    # Deep mode: deduplicate by full path
    seen_paths = {}
    for fp, d, is_sub in all_files:
        if fp not in seen_paths:
            seen_paths[fp] = (fp, d, is_sub)
    all_unique = list(seen_paths.values())
else:
    # Standard mode: deduplicate by basename (original behaviour)
    seen_base = {}
    for f, d, is_sub in all_files:
        base = os.path.basename(f)
        if base not in seen_base or os.path.getmtime(f) > os.path.getmtime(seen_base[base][0]):
            seen_base[base] = (f, d, is_sub)
    all_unique = list(seen_base.values())

files_sorted = sorted(all_unique, key=lambda x: os.path.getmtime(x[0]), reverse=True)
if skip_current and files_sorted:
    if current_sid:
        # the transcript itself, plus its subagents under <sid>/subagents/
        files_sorted = [e for e in files_sorted
                        if os.path.basename(e[0]) != current_sid + '.jsonl'
                        and f'/{current_sid}/' not in e[0]]
    else:
        files_sorted = files_sorted[1:]
if count > 0:
    files_sorted = files_sorted[:count]

# ── Load sessions-index from all dirs ─────────────────────────────────────────
index_map = {}
for d in project_dirs:
    try:
        with open(os.path.join(d, 'sessions-index.json')) as f:
            for e in json.load(f).get('entries', []):
                index_map[e['sessionId']] = e
    except:
        pass


def to_local(iso):
    try:
        dt = datetime.fromisoformat(iso.replace('Z', '+00:00'))
        return (dt + tz_offset).strftime('%Y-%m-%d %H:%M')
    except:
        return iso


GAP_THRESHOLD = 30  # minutes — a silence longer than this is not session time


def active_minutes(stamps):
    """Minutes with activity: sum the steps between consecutive events, skipping
    any step longer than GAP_THRESHOLD. First→last alone counts every night a
    session sat idle before being resumed — measured 2026-09-26: 9c77f5f5 read
    5,619 min (four days) as one span."""
    times = []
    for s in stamps:
        try:
            times.append(datetime.fromisoformat(s.replace('Z', '+00:00')))
        except:
            pass
    times.sort()
    total = 0.0
    for a, b in zip(times, times[1:]):
        step = (b - a).total_seconds()
        if step <= GAP_THRESHOLD * 60:
            total += step
    return int(total / 60)


# ── Parse sessions ─────────────────────────────────────────────────────────────
sessions = []
for fp, source_dir, is_subagent in files_sorted:
    sid = os.path.basename(fp).replace('.jsonl', '')
    stamps = []
    first_ts = last_ts = None
    branch = summary_text = None
    is_sidechain = False
    real_human = []
    assistant_count = 0
    tool_calls = 0

    try:
        with open(fp) as fh:
            for line in fh:
                try:
                    obj = json.loads(line)
                except:
                    continue
                ts = obj.get('timestamp')
                if ts:
                    stamps.append(ts)
                    if not first_ts or ts < first_ts:
                        first_ts = ts
                    if not last_ts or ts > last_ts:
                        last_ts = ts
                # Claude Code stamps gitBranch on EVERY record. Reading it only
                # from a type=='summary' record made this 'unknown' for every
                # modern session: sampled over the 120 newest transcripts across
                # both roots, summary records 0/120, gitBranch present 120/120.
                if not branch:
                    branch = obj.get('gitBranch') or None

                t = obj.get('type', '')
                if t == 'summary':
                    summary_text = obj.get('summary', '')
                    branch = obj.get('gitBranch', '') or branch
                    is_sidechain = obj.get('isSidechain', False)
                elif t == 'assistant':
                    assistant_count += 1
                    if deep or include_subagents:
                        msg = obj.get('message', {})
                        content = msg.get('content', [])
                        if isinstance(content, list):
                            for c in content:
                                if isinstance(c, dict) and c.get('type') == 'tool_use':
                                    tool_calls += 1
                elif t == 'user':
                    msg = obj.get('message', {})
                    content = msg.get('content', [])
                    text = ''
                    if isinstance(content, list):
                        for c in content:
                            if isinstance(c, dict) and c.get('type') == 'text':
                                text = c.get('text', '').strip()
                                break
                    elif isinstance(content, str):
                        text = content.strip()
                    if text and len(text) > 5 and not is_harness_turn(obj, text):
                        real_human.append(text[:80])
    except:
        continue

    if not first_ts:
        continue

    span_min = 0
    if first_ts and last_ts:
        try:
            t1 = datetime.fromisoformat(first_ts.replace('Z', '+00:00'))
            t2 = datetime.fromisoformat(last_ts.replace('Z', '+00:00'))
            span_min = int((t2 - t1).total_seconds() / 60)
        except:
            pass

    idx = index_map.get(sid, {})
    final_summary = idx.get('summary') or summary_text or (real_human[0] if real_human else 'No summary')
    final_branch = branch or idx.get('gitBranch') or 'unknown'

    entry = {
        'sessionId': sid[:12],
        'repoName': get_repo_name(source_dir, repo_map),
        'startGMT7': to_local(first_ts),
        'endGMT7': to_local(last_ts),
        # durationMin is ACTIVE time (idle gaps > GAP_THRESHOLD removed), so
        # /dig's "Min" column and its "Total time" sum mean work, not wall clock.
        # spanMin keeps the old first→last value.
        'durationMin': active_minutes(stamps),
        'spanMin': span_min,
        'realHumanMessages': len(real_human),
        'assistantMessages': assistant_count,
        'firstPrompt': real_human[0] if real_human else None,
        'gitBranch': final_branch,
        'summary': final_summary[:80],
        'isSidechain': is_sidechain,
    }

    # Extra fields only in deep/subagents mode
    if deep or include_subagents:
        entry['toolCalls'] = tool_calls
        entry['fileSizeKB'] = os.path.getsize(fp) // 1024
        entry['isSubagent'] = is_subagent
        # Which of the THREE tiers, not a yes/no — and the run id, which is the
        # only thing that groups a fan-out's agents back together.
        wf_m = re.search(r'/subagents/workflows/(wf_[^/]+)/', fp)
        entry['tier'] = ('workflow_agent' if wf_m else
                         'subagent' if is_subagent else 'session')
        entry['workflowRunId'] = wf_m.group(1) if wf_m else None

    sessions.append(entry)

sessions.sort(key=lambda s: s['startGMT7'])


def parse_local(s):
    try:
        return datetime.strptime(s, '%Y-%m-%d %H:%M')
    except:
        return None


with_gaps = []
for i, s in enumerate(sessions):
    if i == 0:
        with_gaps.append({"type": "gap", "label": "sleeping / offline"})
    else:
        prev_end = parse_local(sessions[i - 1]['endGMT7'])
        curr_start = parse_local(s['startGMT7'])
        if prev_end and curr_start:
            gap_min = int((curr_start - prev_end).total_seconds() / 60)
            if gap_min > GAP_THRESHOLD:
                with_gaps.append({"type": "gap", "gapMin": gap_min, "label": f"{gap_min}m gap"})
    with_gaps.append(s)
with_gaps.append({"type": "gap", "label": "no session yet"})

# Append coverage metadata when in deep/subagents mode (as a trailing sentinel entry)
_tier_counts = {}
for _s in sessions:
    _t = _s.get('tier', 'session')
    _tier_counts[_t] = _tier_counts.get(_t, 0) + 1

if deep or include_subagents:
    with_gaps.append({
        "type": "coverage",
        "totalFound": total_found,
        "skippedUnreadable": skipped_unreadable,
        "corpusRoots": sorted({os.path.dirname(d.rstrip('/')) for d in project_dirs}),
        "returned": len(sessions),
        "deep": deep,
        "includeSubagents": include_subagents,
        "timezone": tz_name,
        "projectDirs": len(project_dirs),
        "tiers": _tier_counts,
    })

print(json.dumps(with_gaps, indent=2))
